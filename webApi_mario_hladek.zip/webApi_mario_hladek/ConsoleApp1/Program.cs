﻿using System;
using Microsoft.AspNetCore.Http.Connections;
using Microsoft.AspNetCore.SignalR.Client;

namespace ConsoleApp1
{
    class Program
    {
        static async Task Main(string[] args)
        {
            var hubConnection = new HubConnectionBuilder().WithUrl("https://localhost:7035/locationHub").Build();

            hubConnection.On<string>("ReceiveLocations", (mesg) => { 
                Console.WriteLine();  
                Console.WriteLine("Nova obavijest: " + mesg);
                Console.WriteLine("Vrijeme: " + DateTime.Now);
            });

            try
            {
                await hubConnection.StartAsync();
                Console.WriteLine("Pritisnite Enter za izlaz.");
                Console.ReadLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                await hubConnection.DisposeAsync();
            }
        }
    }
}
