﻿namespace pok1_webAPI.Models
{
    public class RecordModel
    {
        public int Id { get; set; }
        public DateTime RequestTime { get; set; }
        public string RequestUrl { get; set; }
        public string RequestBody { get; set; }
        public string ResponseBody { get; set; }
    }
}
