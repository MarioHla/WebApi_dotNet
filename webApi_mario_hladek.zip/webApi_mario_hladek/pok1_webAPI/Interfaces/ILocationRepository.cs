﻿using System.Collections.Generic;
using pok1_webAPI.Models;

namespace pok1_webAPI.Interfaces
{
    public interface ILocationRepository
    {
        IEnumerable<LocationModel> GetAllLocations();
        IEnumerable<LocationModel> GetLocationsByCategory(string category);
        IEnumerable<LocationModel> GetLocationsByName(string query);
        void AddRecord(RecordModel record);
        IEnumerable<RecordModel> GetAllRecords();
    }
}
