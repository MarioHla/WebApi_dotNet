﻿using Microsoft.EntityFrameworkCore;
using pok1_webAPI.Models;

namespace pok1_webAPI.Data
{
    public class DataContext : DbContext
    {
        public DataContext(DbContextOptions<DataContext> options) : base(options){}
        public DbSet<LocationModel> Locations { get; set; }
        public DbSet<RecordModel> Records { get; set; } 


        protected override void OnModelCreating(ModelBuilder modelBuilder)
            {modelBuilder.Entity<LocationModel>().HasKey(lm => new { lm.Id });
        }

    }
}
