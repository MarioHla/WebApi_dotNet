﻿using Microsoft.AspNetCore.SignalR;
using System.Threading.Tasks;

namespace pok1_webAPI.Hubs
{
    public class LocationHub : Hub
    {
        //public async Task SendLocationRequest(string msg) {await Clients.All.SendAsync("ReceiveLocations", msg);}
    }
}
