﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using Newtonsoft.Json;
using pok1_webAPI.Dto;
using pok1_webAPI.Hubs;
using pok1_webAPI.Interfaces;
using pok1_webAPI.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace pok1_webAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LocationsController : ControllerBase
    {
        private readonly IHubContext<LocationHub> _hubContext;
        private readonly ILocationRepository _locationRepository;
        private const double RadiusInMeters = 100;

        public LocationsController(IHubContext<LocationHub> hubContext, ILocationRepository locationRepository)
        {
            _locationRepository = locationRepository;
            _hubContext = hubContext;
        } 

        [HttpPost("searchLocationsInRadius")]
        public async Task<IActionResult> SearchLocations([FromBody] LocationDto request)
        {
            if (request == null) return BadRequest("Nevažeći zahtjev. Provjerite podatke o GPS koordinatama.");

            double latitudeRadians = request.Latitude * Math.PI / 180;
            double longitudeRadians = request.Longitude * Math.PI / 180;

            IEnumerable<LocationModel> locations = _locationRepository.GetAllLocations();
            List<LocationModel> locationsInRadius = new List<LocationModel>();

            foreach (var location in locations)
            {
                double locationLatitudeRadians = location.Latitude * Math.PI / 180;
                double locationLongitudeRadians = location.Longitude * Math.PI / 180;

                double distance = CalculateDistance(latitudeRadians, longitudeRadians, locationLatitudeRadians, locationLongitudeRadians);
                //Console.WriteLine($"Id: {location.Id}, Latitude: {location.Latitude}, Longitude: {location.Longitude}, dist {distance}");
                if (distance <= RadiusInMeters) locationsInRadius.Add(location);
            }

            if (locationsInRadius.Count == 0) return NotFound();
            var logEntry = new RecordModel
            {
                RequestTime = DateTime.Now,
                RequestUrl = Request.Path,
                RequestBody = JsonConvert.SerializeObject(request),
                ResponseBody = JsonConvert.SerializeObject(locationsInRadius)
            };

            _locationRepository.AddRecord(logEntry);
            await _hubContext.Clients.All.SendAsync("ReceiveLocations", "Napravljena je nova pretraga");
            return Ok(locationsInRadius);
        }


        [HttpGet("searchByCategory/{category}")]
        public IActionResult GetLocationsByCategory(string category)
        {
            var locationsByCategory = _locationRepository.GetLocationsByCategory(category);
            return Ok(locationsByCategory);
        }


        [HttpGet("searchByName/{query}")]
        public IActionResult GetLocationsByName(string query)
        {
            var locations = _locationRepository.GetLocationsByName(query); //if (locations.Count == 0) return NotFound();
            return Ok(locations);
        }


        [HttpGet("printRecords")]
        public async Task<IActionResult> GetRecords()
        {
            var records = _locationRepository.GetAllRecords();
            await _hubContext.Clients.All.SendAsync("ReceiveLocations", "Zapisi su pogledani");
            return Ok(records);
        }

        private double CalculateDistance(double lat1, double lon1, double lat2, double lon2)
        {
            const double EarthRadiusInMeters = 6371000;

            double dLat = lat2 - lat1;
            double dLon = lon2 - lon1;

            double a = Math.Sin(dLat / 2) * Math.Sin(dLat / 2) + Math.Cos(lat1) * Math.Cos(lat2) * Math.Sin(dLon / 2) * Math.Sin(dLon / 2);
            double c = 2 * Math.Atan2(Math.Sqrt(a), Math.Sqrt(1 - a));

            double distance = EarthRadiusInMeters * c;
            return distance;
        }
    }
}
